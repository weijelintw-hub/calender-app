# Calendar Diary 產品化實作藍圖

## 目標

將目前 Calendar Diary 原型升級為可實際使用的 iOS 產品，保留 PWA 預覽，並加入可靠的本機保存、可切換的備份提供者、可切換的測試／付費狀態、日程—日記記憶、生活節奏重排、隱私友善診斷與 App Store 驗收所需的基礎。

## 設計原則

1. 日記資料採本機優先；沒有雲端權限或網路時，月曆與日記仍可正常使用。
2. 所有資料操作經由單一 repository 介面，避免 UI 直接依賴 `localStorage`，讓 SQLite、iCloud、Google Drive 與測試記憶體實作可替換。
3. 雲端備份採「明確顯示狀態、可手動備份、可手動還原、可匯出」；不以自建伺服器保存日記內容作為第一版必要條件。
4. 備份提供者與 Premium 權益由 feature flags 控制；測試期不是假按鈕，而是同一套完整功能在暫時開放模式下運作。
5. 診斷紀錄永不包含日記文字、事件標題、地點、照片或任何私人內容，只保存匿名錯誤類型、版本與技術狀態。
6. EventKit 同步使用穩定原生事件 ID、同步快照與衝突提示；若插件無法提供足夠修改資訊，不會假裝能做到完美的最後修改者判定。

## 分階段交付

### A. 底座與資料安全

- 建立 `DataRepository` 與 schema version。
- 將現有 localStorage 資料一次性遷移到新 repository。
- 加入資料匯出、匯入、備份狀態、失敗重試與版本相容性檢查。
- 原生 iOS 優先使用 SQLite／原生安全保存；PWA 保留 IndexedDB fallback。

### B. 備份與換機

- `BackupProvider` 介面先支援本機檔案 JSON 匯出／匯入與 iCloud provider 設計。
- iCloud 版本需使用 Apple 原生 entitlement／CloudKit 設定後才開啟，未設定時顯示可理解的引導。
- Google Drive provider 以獨立適配器加入，只有在 OAuth、App ID、隱私政策與安全儲存完成後才開啟。
- 還原前先做本機快照，提供預覽與明確確認，避免覆蓋使用者目前資料。

### C. Premium 與測試開關

- 建立 `EntitlementProvider`，至少包含 `isPremium`, `isTrialMode`, `source`, `expiresAt`。
- 測試期由設定值控制，Premium 功能全部實際可用並標示「測試期間免費」。
- 正式付費時接 StoreKit 2 或 RevenueCat；提供購買、恢復、訂閱狀態與管理訂閱入口。
- 不在 UI 放無作用的付款按鈕，也不以遠端設定偷偷改變已審核核心功能。

### D. 差異化功能

- 事件完成後的微型復盤：心情、能量、短句與事件連結。
- 歷史上的今天、月度回顧、事件與日記全文搜尋。
- 一鍵重新安排今日剩餘行程；先以可解釋規則引擎實作，再評估 AI。
- 照片、地點、天氣、步數列為後續明確授權的增量功能，不在第一版默默收集。

### E. 原生、診斷與上架

- 驗證 iOS 17+ Calendar Full Access／Write Only／拒絕授權流程。
- 原生通知、前景同步、離線恢復與事件衝突測試。
- 加入隱私友善的 crash／error adapter，可在未設定第三方服務時安全停用。
- 完成 App Privacy、隱私政策、支援與資料刪除說明、TestFlight 測試矩陣與上架文件。

## 完成標準

每一階段都必須同時具備：TypeScript 檢查通過、production build 通過、資料遷移測試、錯誤路徑測試、PWA 行為不退化，以及原生能力在可用環境中有清楚的降級處理。沒有 Apple Developer、CloudKit、Google OAuth 或訂閱服務憑證時，相關功能可以先以安全的 disabled／test mode 編譯，但不可宣稱已完成正式雲端或正式付費營運。
