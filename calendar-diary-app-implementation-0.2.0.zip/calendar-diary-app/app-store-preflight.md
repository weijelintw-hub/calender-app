

## Apple 官方查核（2026-09-01）

來源：[Apple Submitting](https://developer.apple.com/app-store/submitting/)；[Apple App Privacy Details](https://developer.apple.com/app-store/app-privacy-details/)。

Apple 官方指出，App Store Connect 提交新 App 或更新前，必須填寫 App Privacy Details，且需涵蓋開發者本人與整合的第三方合作元件所涉及的資料實務；資料使用方式必須保持準確並隨實作變更更新。Apple 也要求確認 Info.plist 與裝置能力需求相容，並會審查隱私、安全、可靠性與功能品質。此專案使用日曆與 Face ID 權限，需在上架前實機確認權限說明、拒絕權限時的降級流程，以及 App Store Connect 隱私權問卷內容。另需準備商店頁的 App 名稱、描述、圖示、截圖、年齡分級與審查資訊。政府假日資料目前僅作備援，不主動寫回原生行事曆。 

目前專案狀態：原生行事曆入口與同步功能已接回；PWA 顯示原生專用提示；TypeScript、production build、Capacitor sync 與三頁手機預覽通過。EventKit 的新增、修改、刪除與實機雙向變更仍需在 IPA／TestFlight 或 App Store build 上實機驗證。 

Apple 官方另指出，2026 年 4 月 28 日起，App Store Connect 上傳的 App 需使用符合當期 SDK 要求的建置環境；提交前應以 Apple 當期 Xcode／SDK 要求再次確認 Codemagic runner。 

最後更新：2026-09-01。

## References

[1]: https://developer.apple.com/app-store/submitting/ Apple Developer — Submitting
[2]: https://developer.apple.com/app-store/app-privacy-details/ Apple Developer — App Privacy Details

