# Calendar Diary App Privacy Details 資料流對照表

這份表格是 App Store Connect「App Privacy」申報的工程草稿。正式提交前，必須依實際啟用的 SDK、CloudKit container、StoreKit／RevenueCat、診斷服務與照片功能重新核對；不能只複製目前草稿。

| 資料類型 | 目前程式用途 | 是否目前傳出裝置 | 目前處理方式 | 申報注意事項 |
|---|---|---:|---|---|
| 日記文字 | 本機日記、事件完成心得、備份匯出／匯入 | 否，除非使用者主動匯出檔案 | 本機資料層保存；日記鎖定保護入口 | 若啟用 CloudKit，需依實際同步方式申報並更新隱私政策 |
| 行程資料 | 本機月曆、事件心得與 iPhone 行事曆同步 | 可能由 iOS EventKit 依使用者授權讀寫 | 原生權限後讀取／建立／修改／刪除 | 不應宣稱 App 完全不接觸行事曆資料；需說明用途與權限 |
| 照片 | 目前資料模型尚未完成照片雲端流程 | 目前未建立照片上傳服務 | 後續功能需使用者明確選取 | 加入照片功能後，重新檢查照片權限、備份與刪除流程 |
| 心情標籤 | 日記與事件回顧 | 否 | 本機保存並隨本機 JSON 備份 | 不應在未有醫療用途時宣稱健康診斷或心理評估 |
| 裝置／系統資訊 | 錯誤診斷與本機錯誤排查 | 目前只保留本機診斷緩衝區 | 截短錯誤名稱、訊息、版本與 user agent | 若加入 Sentry／Crashlytics，需重新申報收集內容與用途，並不得傳送日記文字 |
| Apple ID／帳號 | 目前不要求 App 專屬帳號 | 否 | 使用者可直接以訪客模式使用 | 若未來啟用 iCloud／CloudKit，依 Apple 平台帳號與雲端資料實際流程更新說明 |
| 付款／訂閱資料 | 目前僅測試免費權益狀態 | 否 | StoreKit 尚未正式啟用 | 正式上線前需依 StoreKit 或 RevenueCat 的實際資料流重新填寫 |

## 工程限制

目前不使用廣告追蹤，也沒有把日記、事件標題、地點、照片或 Apple ID 寫入診斷紀錄。若未來加入第三方分析或錯誤追蹤 SDK，必須先更新此文件、隱私政策、PrivacyInfo.xcprivacy、App Store Connect App Privacy Details 與 App Review Notes，再進入 TestFlight。
