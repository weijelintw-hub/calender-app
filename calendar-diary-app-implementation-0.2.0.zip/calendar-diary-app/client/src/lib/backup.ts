export type BackupPayload = {
  diaries: unknown[];
  events: unknown[];
  holidays: unknown[];
};

export type BackupEnvelope = {
  format: "calendar-diary-backup";
  version: 1;
  createdAt: string;
  checksum: string;
  payload: BackupPayload;
};

export type BackupProviderId = "local-file" | "icloud" | "google-drive";

export type BackupProvider = {
  id: BackupProviderId;
  label: string;
  available: () => boolean;
  backup: (envelope: BackupEnvelope) => Promise<void>;
  restore: () => Promise<BackupEnvelope | null>;
};

function stableJson(value: unknown) {
  return JSON.stringify(value);
}

async function digest(value: string) {
  if (!crypto.subtle) throw new Error("目前環境不支援備份校驗。 ");
  const bytes = new TextEncoder().encode(value);
  const hash = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(hash), (byte) => byte.toString(16).padStart(2, "0")).join("");
}

export async function createBackupEnvelope(payload: BackupPayload): Promise<BackupEnvelope> {
  const normalized: BackupPayload = {
    diaries: Array.isArray(payload.diaries) ? payload.diaries : [],
    events: Array.isArray(payload.events) ? payload.events : [],
    holidays: Array.isArray(payload.holidays) ? payload.holidays : [],
  };
  return {
    format: "calendar-diary-backup",
    version: 1,
    createdAt: new Date().toISOString(),
    checksum: await digest(stableJson(normalized)),
    payload: normalized,
  };
}

export async function validateBackupEnvelope(input: unknown): Promise<BackupEnvelope> {
  if (!input || typeof input !== "object") throw new Error("備份檔格式不正確。 ");
  const value = input as Partial<BackupEnvelope>;
  if (value.format !== "calendar-diary-backup" || value.version !== 1 || !value.payload || typeof value.payload !== "object") throw new Error("這不是可支援的 Calendar Diary 備份檔。 ");
  const payload = value.payload as Partial<BackupPayload>;
  const normalized: BackupPayload = {
    diaries: Array.isArray(payload.diaries) ? payload.diaries : [],
    events: Array.isArray(payload.events) ? payload.events : [],
    holidays: Array.isArray(payload.holidays) ? payload.holidays : [],
  };
  if (typeof value.checksum !== "string" || value.checksum !== await digest(stableJson(normalized))) throw new Error("備份檔校驗失敗，為避免覆蓋目前資料，已停止還原。 ");
  return { format: "calendar-diary-backup", version: 1, createdAt: typeof value.createdAt === "string" ? value.createdAt : new Date().toISOString(), checksum: value.checksum, payload: normalized };
}

export function downloadBackupFile(envelope: BackupEnvelope) {
  const blob = new Blob([JSON.stringify(envelope, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `calendar-diary-backup-${envelope.createdAt.slice(0, 10)}.json`;
  link.click();
  URL.revokeObjectURL(url);
}

export async function readBackupFile(file: File) {
  const raw = JSON.parse(await file.text()) as unknown;
  try {
    return await validateBackupEnvelope(raw);
  } catch (error) {
    if (raw && typeof raw === "object" && (raw as { format?: string }).format === "calendar-diary") {
      const legacy = raw as { diaries?: unknown[]; events?: unknown[]; holidays?: unknown[] };
      return createBackupEnvelope({ diaries: legacy.diaries ?? [], events: legacy.events ?? [], holidays: legacy.holidays ?? [] });
    }
    throw error;
  }
}

export const localFileBackupProvider: BackupProvider = {
  id: "local-file",
  label: "本機備份檔",
  available: () => typeof window !== "undefined",
  backup: async (envelope) => downloadBackupFile(envelope),
  restore: async () => null,
};

export const unavailableCloudBackupProvider = (id: "icloud" | "google-drive", label: string): BackupProvider => ({
  id,
  label,
  available: () => false,
  backup: async () => { throw new Error(`${label} 備份尚未完成設定。`); },
  restore: async () => { throw new Error(`${label} 還原尚未完成設定。`); },
});
