import { describe, expect, it } from "vitest";
import { premiumLabel, type EntitlementState } from "./entitlements";

const state = (overrides: Partial<EntitlementState>): EntitlementState => ({
  mode: "test-free",
  premium: true,
  source: "test-mode",
  checkedAt: "2026-09-01T00:00:00.000Z",
  ...overrides,
});

describe("entitlement presentation", () => {
  it("clearly marks the temporary free testing period", () => {
    expect(premiumLabel(state({}))).toBe("測試期間免費");
  });

  it("does not describe an unverified store state as active Premium", () => {
    expect(premiumLabel(state({ mode: "storekit", premium: false, source: "unknown" }))).toBe("升級 Premium");
  });

  it("shows active Premium when the provider has verified access", () => {
    expect(premiumLabel(state({ mode: "storekit", premium: true, source: "app-store" }))).toBe("Premium 已啟用");
  });
});
