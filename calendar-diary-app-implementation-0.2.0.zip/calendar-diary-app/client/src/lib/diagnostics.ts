import { persistentGet, persistentSet } from "@/lib/persistent-store";

const DIAGNOSTICS_KEY = "calendar-diary:diagnostics";
const MAX_ENTRIES = 50;

type DiagnosticEntry = {
  id: string;
  createdAt: string;
  name: string;
  message: string;
  context: string;
  appVersion: string;
  platform: string;
};

function safeError(error: unknown) {
  if (error instanceof Error) return { name: error.name.slice(0, 80), message: error.message.slice(0, 240) };
  return { name: "UnknownError", message: String(error).slice(0, 240) };
}

export async function reportDiagnostic(error: unknown, context: string) {
  const safe = safeError(error);
  const entry: DiagnosticEntry = {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    createdAt: new Date().toISOString(),
    name: safe.name,
    message: safe.message,
    context: context.slice(0, 80),
    appVersion: "1.0.0",
    platform: typeof navigator === "undefined" ? "unknown" : navigator.userAgent.slice(0, 160),
  };
  try {
    const raw = await persistentGet(DIAGNOSTICS_KEY);
    const previous = raw ? JSON.parse(raw) as DiagnosticEntry[] : [];
    const entries = Array.isArray(previous) ? previous.slice(-MAX_ENTRIES + 1).concat(entry) : [entry];
    await persistentSet(DIAGNOSTICS_KEY, JSON.stringify(entries));
  } catch {
    console.error("診斷紀錄保存失敗", entry.name, entry.context);
  }
  console.error("Calendar Diary diagnostic", entry);
}

export async function readDiagnostics() {
  try {
    const raw = await persistentGet(DIAGNOSTICS_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed as DiagnosticEntry[] : [];
  } catch {
    return [];
  }
}

export async function clearDiagnostics() {
  await persistentSet(DIAGNOSTICS_KEY, "[]");
}
