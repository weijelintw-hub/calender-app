import { describe, expect, it } from "vitest";
import { suggestReschedule } from "./reschedule";

describe("suggestReschedule", () => {
  it("moves unfinished events into remaining time with breaks", () => {
    const result = suggestReschedule([
      { id: "done", date: "2026-09-01", title: "已完成", time: "09:00", endTime: "10:00", reflection: "完成" },
      { id: "a", date: "2026-09-01", title: "工作 A", time: "10:00", endTime: "11:30" },
      { id: "b", date: "2026-09-01", title: "工作 B", time: "14:00", endTime: "15:00" },
    ], "2026-09-01", { nowMinutes: 12 * 60, breakMinutes: 15 });
    expect(result.map((item) => [item.id, item.suggestedTime, item.suggestedEndTime])).toEqual([["a", "12:15", "13:45"], ["b", "14:00", "15:00"]]);
  });

  it("does not schedule beyond the configured day end", () => {
    const result = suggestReschedule([{ id: "a", date: "2026-09-01", title: "工作", time: "10:00", endTime: "12:00" }], "2026-09-01", { nowMinutes: 20 * 60, dayEnd: 21 * 60 });
    expect(result).toEqual([]);
  });
});
