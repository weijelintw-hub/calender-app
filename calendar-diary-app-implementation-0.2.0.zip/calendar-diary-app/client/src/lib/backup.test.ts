import { describe, expect, it } from "vitest";
import { createBackupEnvelope, validateBackupEnvelope } from "./backup";

describe("backup envelope", () => {
  it("creates and validates a versioned backup", async () => {
    const envelope = await createBackupEnvelope({ diaries: [{ id: "d1", body: "private" }], events: [], holidays: [] });
    await expect(validateBackupEnvelope(envelope)).resolves.toEqual(envelope);
  });

  it("rejects a tampered payload", async () => {
    const envelope = await createBackupEnvelope({ diaries: [], events: [{ id: "e1" }], holidays: [] });
    const tampered = { ...envelope, payload: { ...envelope.payload, events: [{ id: "e2" }] } };
    await expect(validateBackupEnvelope(tampered)).rejects.toThrow("校驗失敗");
  });

  it("rejects unsupported formats", async () => {
    await expect(validateBackupEnvelope({ format: "unknown", version: 1 })).rejects.toThrow("可支援");
  });
});
