export type RescheduleEvent = {
  id: string;
  date: string;
  title: string;
  time?: string;
  endTime?: string;
  reflection?: string;
};

export type RescheduleSuggestion = RescheduleEvent & {
  suggestedTime: string;
  suggestedEndTime: string;
};

function minutes(value?: string) {
  const match = value?.match(/^(\d{1,2}):(\d{2})$/);
  return match ? Number(match[1]) * 60 + Number(match[2]) : null;
}

function clock(value: number) {
  const normalized = Math.max(0, Math.min(value, 23 * 60 + 59));
  return `${String(Math.floor(normalized / 60)).padStart(2, "0")}:${String(normalized % 60).padStart(2, "0")}`;
}

export function suggestReschedule(events: RescheduleEvent[], date: string, options: { nowMinutes?: number; dayStart?: number; dayEnd?: number; breakMinutes?: number } = {}) {
  const dayStart = options.dayStart ?? 8 * 60;
  const dayEnd = options.dayEnd ?? 21 * 60;
  const breakMinutes = options.breakMinutes ?? 15;
  const nowMinutes = options.nowMinutes ?? dayStart;
  const cursorStart = Math.max(dayStart, nowMinutes + breakMinutes);
  const candidates = events.filter((event) => event.date === date && !event.reflection && minutes(event.time) !== null).sort((a, b) => (minutes(a.time) ?? 0) - (minutes(b.time) ?? 0));
  let cursor = cursorStart;
  const result: RescheduleSuggestion[] = [];
  for (const event of candidates) {
    const originalStart = minutes(event.time) ?? cursor;
    const originalEnd = minutes(event.endTime) ?? originalStart + 60;
    const duration = Math.max(15, originalEnd - originalStart);
    if (cursor + duration > dayEnd) break;
    result.push({ ...event, suggestedTime: clock(cursor), suggestedEndTime: clock(cursor + duration) });
    cursor += duration + breakMinutes;
  }
  return result;
}
