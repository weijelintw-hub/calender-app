import { Capacitor } from "@capacitor/core";
import { persistentGet, persistentSet } from "@/lib/persistent-store";

export type SubscriptionMode = "test-free" | "storekit";
export type EntitlementState = {
  mode: SubscriptionMode;
  premium: boolean;
  source: "test-mode" | "app-store" | "unknown";
  checkedAt: string;
};

const MODE_KEY = "calendar-diary:subscription-mode";
const DEFAULT_MODE: SubscriptionMode = "test-free";

function configuredMode(): SubscriptionMode {
  const value = import.meta.env.VITE_SUBSCRIPTION_MODE;
  return value === "storekit" ? "storekit" : DEFAULT_MODE;
}

export async function getEntitlementState(): Promise<EntitlementState> {
  const modeValue = await persistentGet(MODE_KEY);
  const mode = modeValue === "test-free" || modeValue === "storekit" ? modeValue : configuredMode();
  if (mode === "test-free") return { mode, premium: true, source: "test-mode", checkedAt: new Date().toISOString() };
  if (!Capacitor.isNativePlatform() || Capacitor.getPlatform() !== "ios") return { mode, premium: false, source: "unknown", checkedAt: new Date().toISOString() };
  return { mode, premium: false, source: "unknown", checkedAt: new Date().toISOString() };
}

export async function setSubscriptionModeForDevelopment(mode: SubscriptionMode) {
  if (import.meta.env.PROD) throw new Error("正式版本不能從使用者介面切換訂閱模式。 ");
  await persistentSet(MODE_KEY, mode);
}

export function premiumLabel(state: EntitlementState) {
  return state.mode === "test-free" ? "測試期間免費" : state.premium ? "Premium 已啟用" : "升級 Premium";
}
