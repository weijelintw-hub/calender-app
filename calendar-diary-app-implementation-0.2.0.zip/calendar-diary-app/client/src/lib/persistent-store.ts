import { Capacitor } from "@capacitor/core";
import { CapacitorSQLite } from "@capacitor-community/sqlite";

const DATABASE_NAME = "calendar_diary";
const DATABASE_VERSION = 1;
const STORE_NAME = "calendar-diary-store";
const NATIVE_KEY_PREFIX = "calendar-diary:";

type StorageBackend = "sqlite" | "indexeddb" | "memory";

let backendPromise: Promise<StorageBackend> | undefined;
let sqliteReady: Promise<void> | undefined;
let database: IDBDatabase | undefined;

function isNativeSQLiteAvailable() {
  return typeof window !== "undefined" && Capacitor.isNativePlatform() && Capacitor.getPlatform() === "ios";
}

function randomSecret() {
  const bytes = new Uint8Array(32);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
}

async function ensureSQLite() {
  if (!isNativeSQLiteAvailable()) throw new Error("SQLite 只在原生 iOS 環境提供。");
  if (!sqliteReady) {
    sqliteReady = (async () => {
      const secretState = await CapacitorSQLite.isSecretStored();
      if (!secretState.result) await CapacitorSQLite.setEncryptionSecret({ passphrase: randomSecret() });
      await CapacitorSQLite.createConnection({ database: DATABASE_NAME, version: DATABASE_VERSION, encrypted: true, mode: "secret", readonly: false });
      await CapacitorSQLite.open({ database: DATABASE_NAME, readonly: false });
      await CapacitorSQLite.execute({
        database: DATABASE_NAME,
        statements: `CREATE TABLE IF NOT EXISTS kv_store (key TEXT PRIMARY KEY NOT NULL, value TEXT NOT NULL, updated_at INTEGER NOT NULL);`,
        transaction: true,
      });
    })();
  }
  return sqliteReady;
}

function openIndexedDB() {
  if (database) return Promise.resolve(database);
  if (typeof indexedDB === "undefined") return Promise.reject(new Error("此環境沒有可用的本機資料庫。"));
  return new Promise<IDBDatabase>((resolve, reject) => {
    const request = indexedDB.open(STORE_NAME, 1);
    request.onupgradeneeded = () => {
      request.result.createObjectStore("kv");
    };
    request.onsuccess = () => {
      database = request.result;
      database.onversionchange = () => database?.close();
      resolve(database);
    };
    request.onerror = () => reject(request.error ?? new Error("無法開啟本機資料庫。"));
  });
}

async function selectBackend(): Promise<StorageBackend> {
  if (isNativeSQLiteAvailable()) {
    try {
      await ensureSQLite();
      return "sqlite";
    } catch (error) {
      console.error("SQLite 初始化失敗，改用 IndexedDB：", error);
    }
  }
  try {
    await openIndexedDB();
    return "indexeddb";
  } catch (error) {
    console.error("IndexedDB 初始化失敗，改用記憶體資料層：", error);
    return "memory";
  }
}

function backend() {
  backendPromise ??= selectBackend();
  return backendPromise;
}

const memoryStore = new Map<string, string>();

async function readIndexedDB(key: string) {
  const db = await openIndexedDB();
  return new Promise<string | null>((resolve, reject) => {
    const request = db.transaction("kv", "readonly").objectStore("kv").get(key);
    request.onsuccess = () => resolve(typeof request.result === "string" ? request.result : null);
    request.onerror = () => reject(request.error ?? new Error("無法讀取本機資料。"));
  });
}

async function writeIndexedDB(key: string, value: string) {
  const db = await openIndexedDB();
  return new Promise<void>((resolve, reject) => {
    const request = db.transaction("kv", "readwrite").objectStore("kv").put(value, key);
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error ?? new Error("無法保存本機資料。"));
  });
}

export async function persistentGet(key: string) {
  const selected = await backend();
  if (selected === "sqlite") {
    await ensureSQLite();
    const result = await CapacitorSQLite.query({ database: DATABASE_NAME, statement: "SELECT value FROM kv_store WHERE key = ? LIMIT 1", values: [`${NATIVE_KEY_PREFIX}${key}`], readonly: true });
    return (result.values?.[0] as { value?: string } | undefined)?.value ?? null;
  }
  if (selected === "indexeddb") return readIndexedDB(key);
  return memoryStore.get(key) ?? null;
}

export async function persistentSet(key: string, value: string) {
  const selected = await backend();
  if (selected === "sqlite") {
    await ensureSQLite();
    await CapacitorSQLite.run({ database: DATABASE_NAME, statement: "INSERT INTO kv_store (key, value, updated_at) VALUES (?, ?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at", values: [`${NATIVE_KEY_PREFIX}${key}`, value, Date.now()], transaction: true });
    return;
  }
  if (selected === "indexeddb") {
    await writeIndexedDB(key, value);
    return;
  }
  memoryStore.set(key, value);
}

export async function persistentRemove(key: string) {
  const selected = await backend();
  if (selected === "sqlite") {
    await ensureSQLite();
    await CapacitorSQLite.run({ database: DATABASE_NAME, statement: "DELETE FROM kv_store WHERE key = ?", values: [`${NATIVE_KEY_PREFIX}${key}`], transaction: true });
    return;
  }
  if (selected === "indexeddb") {
    const db = await openIndexedDB();
    await new Promise<void>((resolve, reject) => {
      const request = db.transaction("kv", "readwrite").objectStore("kv").delete(key);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error ?? new Error("無法刪除本機資料。"));
    });
    return;
  }
  memoryStore.delete(key);
}

export async function getStorageBackend() {
  return backend();
}

export async function migrateLocalStorageKeys(keys: readonly string[]) {
  if (typeof window === "undefined") return { migrated: 0, skipped: 0 };
  let migrated = 0;
  let skipped = 0;
  for (const key of keys) {
    const oldValue = window.localStorage.getItem(key);
    if (oldValue === null || (await persistentGet(key)) !== null) {
      skipped += 1;
      continue;
    }
    await persistentSet(key, oldValue);
    migrated += 1;
  }
  return { migrated, skipped };
}
