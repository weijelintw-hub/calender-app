# Calendar Diary 1.0.0 原始碼

此封裝是 Calendar Diary 1.0.0 正式版的原始碼，包含 React/Vite PWA、Capacitor iOS 專案、EventKit／Face ID／本地通知橋接，以及 Codemagic 的 iOS IPA workflow。

## 本機啟動

```bash
pnpm install
pnpm run dev
```

## 驗證與建置

```bash
pnpm exec tsc --noEmit
pnpm run build
pnpm exec cap sync ios
```

Linux 或 Windows 無法直接執行 Xcode。要產生 iOS IPA，請將此專案推到 GitHub 或 GitLab，再在 Codemagic 選取 `ios-unsigned-sideload` workflow。建置成功後下載 `calendar-diary-unsigned.ipa`，再使用 Windows 版 Sideloadly 側載到 iPhone。

## 重要檔案

- `client/src/pages/Home.tsx`：PWA 月曆、日記、設定、假日更新與資料匯入匯出。
- `client/src/lib/native-calendar.ts`：iOS EventKit 讀取、寫入、修改與刪除橋接。
- `client/src/lib/security.ts`：Face ID／裝置驗證與自訂密碼邏輯。
- `codemagic.yaml`：unsigned IPA 與 signed development IPA workflows。
- `ios/App/App/Info.plist`：行事曆與 Face ID 隱私權說明。

此封裝不包含 `node_modules`、`dist`、`.git`、開發日誌或任何使用者本機資料。
