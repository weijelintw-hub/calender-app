# Calendar Diary 1.0.0 原始碼

此專案包含 Calendar Diary 的 PWA 預覽、Capacitor iOS 原生外殼、行事曆／Face ID／本地通知橋接、臺灣政府假日資料與 GitHub Actions IPA 打包腳本。

## PWA 預覽

```bash
pnpm install
pnpm run dev
```

啟動後開啟終端機顯示的本機網址即可預覽；使用 `/diary` 可直接進入日記頁，使用 `/settings` 可直接進入設定頁。

## GitHub Actions 產生 IPA

將整個專案推到 GitHub，確認 `.github/workflows/build.yml` 已存在。進入 GitHub 的 **Actions** 分頁，選擇 **Build Calendar Diary iOS IPA**，按 **Run workflow**。完成後在該次工作流程的 **Artifacts** 下載 `calendar-diary-unsigned-ipa`，內含 `calendar-diary-unsigned.ipa`。

這是未簽名的 Debug IPA，需使用 Sideloadly 以 Apple ID 側載到 iPhone；Linux 或 Windows 不能直接執行 Xcode，GitHub Actions 會使用 macOS runner 建置。

## 驗證指令

```bash
pnpm exec tsc --noEmit
pnpm run build
pnpm exec cap sync ios
```

## 主要檔案

- `client/src/pages/Home.tsx`：月曆、日記、設定、假日更新與日記日期編輯。
- `client/src/lib/native-calendar.ts`：iOS EventKit 讀取與寫回。
- `client/src/lib/security.ts`：Face ID／裝置驗證與自訂密碼。
- `codemagic.yaml`：Codemagic unsigned／signed workflows。
- `.github/workflows/build.yml`：GitHub Actions macOS IPA workflow。
- `ios/App/App/Info.plist`：行事曆與 Face ID 隱私權說明。

封裝不包含 `node_modules`、`dist`、`.git`、開發日誌或使用者本機資料。
