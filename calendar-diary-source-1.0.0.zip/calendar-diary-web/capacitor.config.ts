import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.calendardiary.app',
  appName: 'Calendar Diary',
  webDir: 'dist/public'
};

export default config;
