/* Design philosophy: Soft Editorial Utility — calm ivory surfaces, blue index lines, amber diary accents, and clear calendar hierarchy. */
import Home from "@/pages/Home";

export default function App() {
  return <Home />;
}
