import { Capacitor } from "@capacitor/core";
import { Calendar, type CalendarEvent, type CreateEventOptions } from "@capacitor/calendar";

export type NativeCalendarEvent = CalendarEvent;

export const isNativeIOS = () => Capacitor.isNativePlatform() && Capacitor.getPlatform() === "ios";

export async function requestNativeCalendarAccess() {
  if (!isNativeIOS()) throw new Error("此功能只在原生 iOS 測試版提供。");
  return Calendar.requestPermissions({ permissions: ["readCalendar", "writeCalendar"] });
}

export async function listNativeEvents(startDate: number, endDate: number) {
  if (!isNativeIOS()) throw new Error("目前是 PWA 預覽，尚未連接 iPhone 系統行事曆。");
  const result = await Calendar.findEvents({ startDate, endDate });
  return result.events;
}

export async function listManagedHolidayEvents() {
  if (!isNativeIOS()) throw new Error("目前是 PWA 預覽，尚未連接 iPhone 系統行事曆。");
  const result = await Calendar.findEvents({ notes: "Calendar Diary Holiday:" });
  return result.events;
}

export async function createNativeEvent(options: CreateEventOptions) {
  if (!isNativeIOS()) throw new Error("目前是 PWA 預覽，請在 Codemagic 側載的 iOS App 中測試。");
  return Calendar.createEvent(options);
}

export async function modifyNativeEvent(filter: { title?: string; startDate?: number; endDate?: number; calendarName?: string }, options: Partial<CreateEventOptions>) {
  if (!isNativeIOS()) throw new Error("目前是 PWA 預覽，請在 Codemagic 側載的 iOS App 中測試。");
  return Calendar.modifyEvent({ filter, newEvent: options });
}

export async function deleteNativeEvent(eventId: string) {
  if (!isNativeIOS()) throw new Error("目前是 PWA 預覽，請在 Codemagic 側載的 iOS App 中測試。");
  return Calendar.deleteEvent({ id: eventId });
}

export async function openNativeCalendar(date = new Date()) {
  if (!isNativeIOS()) throw new Error("目前是 PWA 預覽，尚未連接 iPhone 系統行事曆。");
  return Calendar.openCalendar({ date: date.getTime() });
}
