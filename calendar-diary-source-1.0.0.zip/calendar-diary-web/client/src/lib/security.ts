/* Design and security note: the PWA uses Web Crypto for passcode hashing and WebAuthn platform authentication. WebAuthn responses are used as a local UI gate in this static build; a server-backed verifier is required for high-assurance account authentication. */

export type LocalPasskey = { credentialId: string; rpId: string };

function toBase64Url(bytes: ArrayBuffer) {
  const binary = String.fromCharCode(...Array.from(new Uint8Array(bytes)));
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

function fromBase64Url(value: string) {
  const padded = value.replace(/-/g, "+").replace(/_/g, "/") + "===".slice((value.length + 3) % 4);
  const binary = atob(padded);
  return Uint8Array.from(binary, (character) => character.charCodeAt(0));
}

function randomBytes(size: number) {
  const bytes = new Uint8Array(size);
  crypto.getRandomValues(bytes);
  return bytes;
}

export function isWebAuthnAvailable() {
  return typeof window !== "undefined" && window.isSecureContext && "credentials" in navigator && "PublicKeyCredential" in window;
}

export function createSalt() {
  return toBase64Url(randomBytes(16).buffer);
}

export async function hashPasscode(passcode: string, salt: string) {
  if (!crypto.subtle) throw new Error("Web Crypto 不可用，無法安全保存鎖定密碼。");
  const input = new TextEncoder().encode(`${salt}:${passcode}`);
  const digest = await crypto.subtle.digest("SHA-256", input);
  return toBase64Url(digest);
}

export async function registerLocalPasskey(): Promise<LocalPasskey> {
  if (!isWebAuthnAvailable()) throw new Error("目前瀏覽器或連線環境不支援 Face ID／裝置密碼驗證。");
  const rpId = window.location.hostname;
  const credential = await navigator.credentials.create({
    publicKey: {
      challenge: randomBytes(32),
      rp: { name: "Calendar Diary", id: rpId },
      user: { id: randomBytes(16), name: "calendar-diary-user", displayName: "Calendar Diary" },
      pubKeyCredParams: [{ type: "public-key", alg: -7 }, { type: "public-key", alg: -257 }],
      authenticatorSelection: { authenticatorAttachment: "platform", residentKey: "preferred", userVerification: "required" },
      timeout: 60000,
    },
  });
  if (!(credential instanceof PublicKeyCredential)) throw new Error("未完成裝置驗證。");
  return { credentialId: toBase64Url(credential.rawId), rpId };
}

export async function authenticateLocalPasskey(passkey: LocalPasskey) {
  if (!isWebAuthnAvailable()) throw new Error("目前瀏覽器或連線環境不支援 Face ID／裝置密碼驗證。");
  const credential = await navigator.credentials.get({
    publicKey: {
      challenge: randomBytes(32),
      rpId: passkey.rpId,
      allowCredentials: [{ id: fromBase64Url(passkey.credentialId), type: "public-key", transports: ["internal"] }],
      userVerification: "required",
      timeout: 60000,
    },
  });
  return credential instanceof PublicKeyCredential;
}
