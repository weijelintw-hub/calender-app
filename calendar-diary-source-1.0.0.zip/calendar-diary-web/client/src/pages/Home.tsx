/* Design philosophy: Soft Editorial Utility — mobile-first calendar navigation, warm diary editing, and settings grouped like a calm preference sheet. */
import { useEffect, useMemo, useRef, useState } from "react";
import { authenticateLocalPasskey, createSalt, hashPasscode, registerLocalPasskey, type LocalPasskey } from "@/lib/security";
import { createNativeEvent, deleteNativeEvent, isNativeIOS, listManagedHolidayEvents, listNativeEvents, modifyNativeEvent, openNativeCalendar, requestNativeCalendarAccess } from "@/lib/native-calendar";
import { LocalNotifications } from "@capacitor/local-notifications";
import { BiometricAuth } from "@aparajita/capacitor-biometric-auth";

import {
  ArrowLeft,
  ArrowRight,
  BookOpen,
  CalendarDays,
  CalendarRange,
  Check,
  ChevronDown,
  Clock3,
  ExternalLink,
  FilePenLine,
  LockKeyhole,
  Menu,
  MoreHorizontal,
  Palette,
  Fingerprint,
  KeyRound,
  Trash2,
  Download,
  Upload,
  Plus,
  QrCode,
  RefreshCw,
  Search,
  Settings,
  Sparkles,
  SunMedium,
  X,
} from "lucide-react";

const monthNames = ["一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "十一月", "十二月"];
const weekDays = ["日", "一", "二", "三", "四", "五", "六"];

type Holiday = { date: string; name: string; dayOff: boolean };
type EventItem = { id: string; date: string; title: string; time?: string; tone: "blue" | "amber" | "green"; nativeId?: string; source?: "local" | "device" | "holiday" };
type DiaryEntry = { id: string; date: string; title: string; body: string; mood: string };
type Composer = { kind: "diary" | "event"; diaryId?: string; eventId?: string };
type LockSettings = { enabled: boolean; passcodeHash?: string; passcodeSalt?: string; passkey?: LocalPasskey; nativeBiometric?: boolean };
type SecurityMode = "setup" | "unlock" | null;

const STORAGE_KEYS = { diaries: "calendar-diary:diaries", events: "calendar-diary:events", holidays: "calendar-diary:holidays", lock: "calendar-diary:lock", settings: "calendar-diary:settings", seedCleanupEvents: "calendar-diary:seed-cleanup-events-v1", seedCleanupDiaries: "calendar-diary:seed-cleanup-diaries-v1" } as const;
const HOLIDAY_SOURCE = "https://raw.githubusercontent.com/ruyut/TaiwanCalendar/master/data/";

function readLocal<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const value = window.localStorage.getItem(key);
    return value ? (JSON.parse(value) as T) : fallback;
  } catch {
    return fallback;
  }
}

const springFestivalNames: Record<string, string> = {
  "2026-02-13": "春節",
  "2026-02-14": "春節",
  "2026-02-15": "小年夜",
  "2026-02-16": "除夕",
  "2026-02-17": "春節",
  "2026-02-18": "春節",
  "2026-02-19": "春節",
  "2026-02-20": "補假",
  "2026-02-21": "春節",
  "2026-02-22": "春節",
};

function normalizeHolidayRecord(record: { date?: string; isHoliday?: boolean; description?: string }) {
  if (!record.date) return null;
  const compact = record.date.replace(/-/g, "");
  if (!/^\d{8}$/.test(compact)) return null;
  const date = `${compact.slice(0, 4)}-${compact.slice(4, 6)}-${compact.slice(6, 8)}`;
  const sourceName = (record.description ?? "").trim();
  const name = date.endsWith("-01-01") ? "元旦" : sourceName.includes("孔子誕辰紀念日") ? "教師節" : sourceName || springFestivalNames[date] || "";
  if (!name) return null;
  return { date, name, dayOff: Boolean(record.isHoliday || springFestivalNames[date]) } satisfies Holiday;
}

function addGovernmentMakeupHolidays(records: Holiday[], year: number) {
  const byDate = new Map(records.map((record) => [record.date, record]));
  const isNonWorking = (date: string) => {
    const day = new Date(`${date}T12:00:00`).getDay();
    return day === 0 || day === 6 || byDate.get(date)?.dayOff === true;
  };
  const shiftToWorkday = (date: string, direction: -1 | 1) => {
    let candidate = date;
    do { candidate = dateKey(new Date(new Date(`${candidate}T12:00:00`).getTime() + direction * 86400000)); } while (isNonWorking(candidate));
    return candidate;
  };
  const explicitMakeups = records.filter((record) => record.dayOff && record.name.includes("補假"));
  records.filter((record) => record.dayOff && record.date.startsWith(`${year}-`)).forEach((record) => {
    const day = new Date(`${record.date}T12:00:00`).getDay();
    if (day !== 0 && day !== 6) return;
    const hasOfficialMakeupNearby = explicitMakeups.some((makeup) => Math.abs(new Date(`${makeup.date}T12:00:00`).getTime() - new Date(`${record.date}T12:00:00`).getTime()) <= 10 * 86400000);
    if (hasOfficialMakeupNearby) return;
    const makeupDate = shiftToWorkday(record.date, day === 6 ? -1 : 1);
    if (!byDate.has(makeupDate)) byDate.set(makeupDate, { date: makeupDate, name: "補假", dayOff: true });
  });
  return Array.from(byDate.values()).sort((a, b) => a.date.localeCompare(b.date));
}

function mergeById<T extends { id: string }>(current: T[], incoming: T[]) {
  const map = new Map(current.map((item) => [item.id, item]));
  incoming.forEach((item) => map.set(item.id, item));
  return Array.from(map.values());
}
function escapeIcs(value: string) { return value.replace(/\\/g, "\\\\").replace(/;/g, "\\;").replace(/,/g, "\\,").replace(/\r?\n/g, "\\n"); }
function icsDate(date: string) { return date.replace(/-/g, ""); }
function icsDateTime(date: string, time?: string) { const match = time?.match(/^(\d{1,2}):(\d{2})$/); if (!match) return null; const hour = match[1].padStart(2, "0"); return `${icsDate(date)}T${hour}${match[2]}00`; }
function icsEndDateTime(date: string, time?: string) { const match = time?.match(/^(\d{1,2}):(\d{2})$/); if (!match) return null; const value = new Date(`${date}T${match[1].padStart(2, "0")}:${match[2]}:00`); value.setHours(value.getHours() + 1); return `${dateKey(value).replace(/-/g, "")}T${String(value.getHours()).padStart(2, "0")}${String(value.getMinutes()).padStart(2, "0")}00`; }
function nextDate(date: string) { const value = new Date(`${date}T12:00:00`); value.setDate(value.getDate() + 1); return dateKey(value); }

const holidaySeed: Holiday[] = addGovernmentMakeupHolidays([
  { date: "2026-01-01", name: "元旦", dayOff: true },
  { date: "2026-02-13", name: "春節", dayOff: true },
  { date: "2026-02-14", name: "春節", dayOff: true },
  { date: "2026-02-15", name: "小年夜", dayOff: true },
  { date: "2026-02-16", name: "除夕", dayOff: true },
  { date: "2026-02-17", name: "春節", dayOff: true },
  { date: "2026-02-18", name: "春節", dayOff: true },
  { date: "2026-02-19", name: "春節", dayOff: true },
  { date: "2026-02-20", name: "補假", dayOff: true },
  { date: "2026-02-21", name: "春節", dayOff: true },
  { date: "2026-02-22", name: "春節", dayOff: true },
  { date: "2026-02-27", name: "補假", dayOff: true },
  { date: "2026-02-28", name: "和平紀念日", dayOff: true },
  { date: "2026-04-03", name: "補假", dayOff: true },
  { date: "2026-04-04", name: "兒童節", dayOff: true },
  { date: "2026-04-05", name: "清明節", dayOff: true },
  { date: "2026-04-06", name: "補假", dayOff: true },
  { date: "2026-05-01", name: "勞動節", dayOff: true },
  { date: "2026-06-19", name: "端午節", dayOff: true },
  { date: "2026-09-25", name: "中秋節", dayOff: true },
  { date: "2026-09-28", name: "教師節", dayOff: true },
  { date: "2026-10-09", name: "補假", dayOff: true },
  { date: "2026-10-10", name: "國慶日", dayOff: true },
  { date: "2026-10-25", name: "臺灣光復暨金門古寧頭大捷紀念日", dayOff: true },
  { date: "2026-10-26", name: "補假", dayOff: true },
  { date: "2026-12-25", name: "行憲紀念日", dayOff: true },
  { date: "2026-09-03", name: "軍人節", dayOff: false },
], 2026);

const eventSeed: EventItem[] = [
  { id: "event-1", date: "2026-08-31", title: "整理八月的日記", time: "09:30", tone: "amber" },
  { id: "event-2", date: "2026-09-03", title: "晨間散步", time: "07:30", tone: "green" },
  { id: "event-3", date: "2026-09-07", title: "產品週會", time: "14:00", tone: "blue" },
  { id: "event-4", date: "2026-09-28", title: "秋日閱讀計畫", time: "全天", tone: "amber" },
];

const diarySeed: DiaryEntry[] = [];
const demoEventIds = new Set(["event-1", "event-2", "event-3", "event-4"]);
const demoEventSignatures = new Set(["2026-08-31|整理八月的日記", "2026-09-03|晨間散步", "2026-09-07|產品週會", "2026-09-28|秋日閱讀計畫"]);
const demoDiaryIds = new Set(["diary-1", "diary-2", "diary-3"]);
const demoDiarySignatures = new Set(["2026-08-31|八月最後一天", "2026-08-27|傍晚的風", "2026-08-18|給自己一個小結"]);
function isDemoEvent(event: EventItem) { return demoEventIds.has(event.id) || demoEventSignatures.has(`${event.date}|${event.title}`); }
function isDemoDiary(diary: DiaryEntry) { return demoDiaryIds.has(diary.id) || demoDiarySignatures.has(`${diary.date}|${diary.title}`); }
function loadCleanCollection<T>(key: string, fallback: T[], cleanupKey: string, isDemo: (item: T) => boolean) {
  const stored = readLocal(key, fallback);
  if (typeof window === "undefined" || window.localStorage.getItem(cleanupKey)) return stored;
  window.localStorage.setItem(cleanupKey, "done");
  return stored.filter((item) => !isDemo(item));
}

function dateKey(date: Date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

function formatDate(dateString: string) {
  const date = new Date(`${dateString}T12:00:00`);
  return `${date.getMonth() + 1}月${date.getDate()}日，星期${weekDays[date.getDay()]}`;
}

function formatShortDate(dateString: string) {
  const date = new Date(`${dateString}T12:00:00`);
  return `${String(date.getMonth() + 1).padStart(2, "0")} / ${String(date.getDate()).padStart(2, "0")}`;
}

function getMonthDays(month: Date, weekStart: "sun" | "mon" = "sun") {
  const start = new Date(month.getFullYear(), month.getMonth(), 1);
  const firstDay = (start.getDay() - (weekStart === "mon" ? 1 : 0) + 7) % 7;
  const daysInMonth = new Date(month.getFullYear(), month.getMonth() + 1, 0).getDate();
  const previousDays = new Date(month.getFullYear(), month.getMonth(), 0).getDate();
  const weekCount = Math.ceil((firstDay + daysInMonth) / 7);
  return Array.from({ length: weekCount * 7 }, (_, index) => {
    const day = index - firstDay + 1;
    if (day < 1) return new Date(month.getFullYear(), month.getMonth() - 1, previousDays + day);
    if (day > daysInMonth) return new Date(month.getFullYear(), month.getMonth() + 1, day - daysInMonth);
    return new Date(month.getFullYear(), month.getMonth(), day);
  });
}

function getHoliday(key: string, holidayList: Holiday[]) {
  return holidayList.find((holiday) => holiday.date === key);
}

function AppSidebar({ active, onChange, onNewDiary }: { active: string; onChange: (value: string) => void; onNewDiary: () => void }) {
  return (
    <aside className="sidebar">
      <div className="brand-lockup">
        <img className="brand-image" src="/manus-storage/calendar-diary-logo_9eaa7769.png" alt="" />
        <div><div className="brand-name">calendar</div><div className="brand-name brand-name-muted">diary</div></div>
      </div>
      <button className="new-entry" onClick={onNewDiary}><Plus size={17} /> 新增日記</button>
      <div className="side-section-label">檢視</div>
      <nav className="side-nav" aria-label="主要導覽">
        {[{ label: "月曆", icon: CalendarDays }, { label: "日記", icon: BookOpen }, { label: "設定", icon: Settings }].map(({ label, icon: Icon }) => (
          <button key={label} className={active === label ? "side-link active" : "side-link"} onClick={() => onChange(label)}><Icon size={17} />{label}</button>
        ))}
      </nav>
      <div className="side-note"><Sparkles size={16} /><div><strong>把今天放在一起</strong><span>行程與心情，都留在同一個日期裡。</span></div></div>
      <div className="sidebar-footer"><button className="side-link" onClick={() => onChange("設定")}><SunMedium size={17} />偏好設定</button><div className="profile-chip"><div className="profile-avatar">林</div><div><strong>我的日常</strong><span>私人工作區</span></div><ChevronDown size={15} /></div></div>
    </aside>
  );
}

function BottomNav({ active, onChange }: { active: string; onChange: (value: string) => void }) {
  return <nav className="bottom-nav" aria-label="手機導覽">{[{ label: "月曆", icon: CalendarDays }, { label: "日記", icon: BookOpen }, { label: "設定", icon: Settings }].map(({ label, icon: Icon }) => <button key={label} className={active === label ? "bottom-link active" : "bottom-link"} onClick={() => onChange(label)}><Icon size={21} /><span>{label}</span></button>)}</nav>;
}

function CalendarPage({ visibleMonth, setVisibleMonth, selected, setSelected, events, diaries, today, weekStart, holidayList, onNewDiary, onNewEvent, onEditEvent, onDeleteEvent }: { visibleMonth: Date; setVisibleMonth: (date: Date) => void; selected: string; setSelected: (date: string) => void; events: EventItem[]; diaries: DiaryEntry[]; today: Date; weekStart: "sun" | "mon"; holidayList: Holiday[]; onNewDiary: () => void; onNewEvent: () => void; onEditEvent: (event: EventItem) => void; onDeleteEvent: (event: EventItem) => void }) {
  const days = useMemo(() => getMonthDays(visibleMonth, weekStart), [visibleMonth, weekStart]);
  const displayedWeekDays = weekStart === "mon" ? [{ label: "一", dayIndex: 1 }, { label: "二", dayIndex: 2 }, { label: "三", dayIndex: 3 }, { label: "四", dayIndex: 4 }, { label: "五", dayIndex: 5 }, { label: "六", dayIndex: 6 }, { label: "日", dayIndex: 0 }] : weekDays.map((label, dayIndex) => ({ label, dayIndex }));
  const selectedDate = new Date(`${selected}T12:00:00`);
  const selectedHoliday = getHoliday(selected, holidayList);
  const selectedEvents = events.filter((event) => event.date === selected);
  const selectedDiaries = diaries.filter((diary) => diary.date === selected);
  const todayKey = dateKey(today);
  const changeMonth = (offset: number) => setVisibleMonth(new Date(visibleMonth.getFullYear(), visibleMonth.getMonth() + offset, 1));

  return <div className="content-wrap">
    <section className="calendar-column" aria-label="月曆">
      <div className="page-intro"><div><div className="eyebrow">CALENDAR DIARY · {visibleMonth.getFullYear()}</div><h1>日程，留一點空間給今天。</h1><p>把要做的事，和值得記住的事，放在同一個日期裡。</p></div><div className="intro-date"><span>今天</span><strong>{`${String(today.getMonth() + 1).padStart(2, "0")}.${String(today.getDate()).padStart(2, "0")}`}</strong><small>星期{weekDays[today.getDay()]}</small></div></div>
      <div className="calendar-toolbar"><div className="month-heading"><h2>{monthNames[visibleMonth.getMonth()]} <em>{visibleMonth.getFullYear()}</em></h2><span className="range-caption">月檢視 · {days.length / 7} 週</span></div><div className="month-controls"><button className="circle-button" onClick={() => changeMonth(-1)} aria-label="上一個月"><ArrowLeft size={17} /></button><button className="circle-button" onClick={() => changeMonth(1)} aria-label="下一個月"><ArrowRight size={17} /></button></div></div>
      <div className="index-line" aria-hidden="true"><span /><small>正在查看 · {monthNames[visibleMonth.getMonth()]} {visibleMonth.getFullYear()}</small></div>
      <div className="calendar-card"><div className="weekday-row">{displayedWeekDays.map((day) => <div key={day.label} className={day.dayIndex === 0 || day.dayIndex === 6 ? "weekday weekend" : "weekday"}>{day.label}</div>)}</div><div className="month-grid">
        {days.map((date) => {
          const key = dateKey(date); const inMonth = date.getMonth() === visibleMonth.getMonth(); const holiday = getHoliday(key, holidayList); const weekend = date.getDay() === 0 || date.getDay() === 6; const isSelected = key === selected; const isToday = key === todayKey; const dayEvents = events.filter((event) => event.date === key); const dayDiaries = diaries.filter((diary) => diary.date === key);
          return <button key={key} className={`day-cell ${!inMonth ? "outside-month" : ""} ${weekend ? "is-weekend" : ""} ${holiday?.dayOff ? "is-holiday" : holiday ? "is-commemorative" : ""} ${isSelected ? "is-selected" : ""}`} onClick={() => setSelected(key)} aria-label={`${key}${holiday ? `，${holiday.name}` : ""}`}><span className="day-number">{date.getDate()}</span>{holiday && <span className="holiday-label">{holiday.name}</span>}<span className="day-markers">{dayEvents.slice(0, 2).map((event) => <i key={event.id} className={`marker ${event.tone}`} />)}{dayDiaries.length > 0 && <i className="marker diary-marker" />}</span>{isToday && <span className="today-ring" />}</button>;
        })}
      </div><div className="legend"><span><i className="legend-dot holiday-dot" />放假／補假</span><span><i className="legend-dot commemorative-dot" />紀念日</span><span><i className="legend-dot diary-dot" />日記</span><span className="dim-note">跨月日期降低亮度</span></div></div>
    </section>
    <aside className="day-panel" aria-label="選取日期內容"><div className="panel-kicker">SELECTED DAY</div><div className="selected-date"><h2>{selectedDate.getDate()}<small>{monthNames[selectedDate.getMonth()]}</small></h2><div><strong>{formatDate(selected)}</strong><span>{selectedHoliday ? selectedHoliday.name : "一個可以慢下來的日子"}</span></div></div><div className="panel-divider" /><div className="panel-section-heading"><span>今日安排</span><span className="count-badge">{selectedEvents.length}</span></div><div className="agenda-list">{selectedEvents.length === 0 ? <div className="empty-agenda"><Clock3 size={20} /><strong>今天還沒有安排</strong><span>新增一件小事，讓這一天有個落點。</span></div> : selectedEvents.map((item) => <div className="agenda-item" key={item.id}><i className={`agenda-line ${item.tone}`} /><div className="agenda-copy"><span>{item.time}</span><strong>{item.title}</strong></div><div className="agenda-actions"><button className="agenda-action" aria-label={`編輯${item.title}`} onClick={(event) => { event.stopPropagation(); onEditEvent(item); }}><FilePenLine size={14} /></button><button className="agenda-action delete" aria-label={`刪除${item.title}`} onClick={(event) => { event.stopPropagation(); onDeleteEvent(item); }}><Trash2 size={14} /></button></div></div>)}</div><div className="panel-section-heading diary-heading"><span>日記片段</span><BookOpen size={16} /></div>{selectedDiaries.length > 0 ? <div className="diary-card"><div className="diary-date">{formatShortDate(selected)} <span>{weekDays[new Date(`${selected}T12:00:00`).getDay()]}</span></div><h3>{selectedDiaries[0].title}</h3><p>{selectedDiaries[0].body}</p><button onClick={onNewDiary}>編輯這一天 <ArrowRight size={14} /></button></div> : <div className="empty-diary"><BookOpen size={19} /><span>在這裡記下一點心情，讓日期不只是日期。</span><button onClick={onNewDiary}>寫下日記 <ArrowRight size={14} /></button></div>}<div className="quick-actions"><button onClick={onNewEvent}><Plus size={15} />新增事件</button><button className="quick-diary" onClick={onNewDiary}><BookOpen size={15} />寫日記</button></div></aside>
  </div>;
}

function DiaryPage({ diaries, onNewDiary, onEditDiary, onDeleteDiary }: { diaries: DiaryEntry[]; onNewDiary: () => void; onEditDiary: (diary: DiaryEntry) => void; onDeleteDiary: (diary: DiaryEntry) => void }) {
  const [query, setQuery] = useState("");
  const filtered = diaries.filter((diary) => `${diary.title} ${diary.body} ${diary.mood}`.toLowerCase().includes(query.toLowerCase()));
  return <div className="page-shell diary-page"><div className="page-heading-row"><div><div className="eyebrow">DIARY INDEX · 2026</div><h1>把日子，重新讀一遍。</h1><p>整理那些值得留住的片段，也可以回到原來的日期重新編輯。</p></div><button className="outline-action" onClick={onNewDiary}><Plus size={16} />寫日記</button></div><div className="diary-toolbar"><div className="diary-count"><strong>{diaries.length}</strong><span>篇日記，正在你的日期裡</span></div><label className="search-field"><Search size={16} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="搜尋標題、內容或心情" /></label></div><div className="diary-index-list">{filtered.length === 0 ? <div className="empty-index"><BookOpen size={22} /><strong>還沒有符合的記錄</strong><span>換個詞搜尋，或替今天寫下一小段。</span></div> : filtered.map((diary, index) => <article className="diary-index-item" key={diary.id} style={{ animationDelay: `${index * 45}ms` }}><div className="diary-index-date"><strong>{formatShortDate(diary.date)}</strong><span>{formatDate(diary.date).split("，")[1]}</span></div><div className="diary-index-copy"><div className="diary-index-meta"><span>{diary.mood}</span><span>{diary.date.slice(0, 4)}</span></div><h2>{diary.title}</h2><p>{diary.body}</p></div><div className="diary-index-actions"><button className="edit-diary" onClick={() => onEditDiary(diary)} aria-label={`編輯${diary.title}`}><FilePenLine size={17} /></button><button type="button" className="delete-diary" onClick={(event) => { event.stopPropagation(); onDeleteDiary(diary); }} aria-label={`刪除${diary.title}`}><Trash2 size={16} /></button></div></article>)}</div></div>;
}

function LockScreen({ lockSettings, passcode, setPasscode, error, busy, onUnlockPasscode, onUnlockFaceId }: { lockSettings: LockSettings; passcode: string; setPasscode: (value: string) => void; error: string; busy: boolean; onUnlockPasscode: () => void; onUnlockFaceId: () => void }) {
  return <div className="lock-screen"><div className="lock-mark"><LockKeyhole size={25} /></div><div className="eyebrow">PRIVATE DIARY</div><h1>日記已鎖定</h1><p>使用 Face ID、iPhone 裝置密碼，或你的自訂鎖定密碼繼續。</p>{lockSettings.passkey && <button className="faceid-action" onClick={onUnlockFaceId} disabled={busy}><Fingerprint size={19} />{busy ? "正在驗證…" : "使用 Face ID／裝置密碼"}</button>}{lockSettings.passcodeHash && <div className="unlock-divider"><span>或輸入鎖定密碼</span></div>}{lockSettings.passcodeHash && <form className="unlock-form" onSubmit={(event) => { event.preventDefault(); onUnlockPasscode(); }}><input autoFocus value={passcode} onChange={(event) => setPasscode(event.target.value)} type="password" inputMode="numeric" autoComplete="current-password" placeholder="輸入鎖定密碼" aria-label="輸入鎖定密碼" /><button type="submit" disabled={busy}><KeyRound size={16} />解鎖</button></form>}{error && <p className="security-error" role="alert">{error}</p>}<small className="security-footnote">此 PWA 的本機鎖定不會把密碼明文保存；若清除瀏覽器資料，需重新設定。</small></div>;
}

function SecuritySetupModal({ passcode, setPasscode, confirmPasscode, setConfirmPasscode, draftPasskey, error, notice, busy, onRegisterFaceId, onSave, onClose }: { passcode: string; setPasscode: (value: string) => void; confirmPasscode: string; setConfirmPasscode: (value: string) => void; draftPasskey?: LocalPasskey; error: string; notice: string; busy: boolean; onRegisterFaceId: () => void; onSave: () => void; onClose: () => void }) {
  return <div className="composer-backdrop" onClick={onClose}><div className="composer security-composer" onClick={(event) => event.stopPropagation()}><div className="composer-top"><div className="composer-kicker">PRIVATE DIARY</div><button className="close-composer" onClick={onClose} aria-label="關閉"><X size={18} /></button></div><h2>設定日記鎖定</h2><p className="security-intro">可選擇 Face ID／iPhone 裝置密碼，也可以設定自訂鎖定密碼作為備援。</p><button className={`faceid-setup ${draftPasskey ? "ready" : ""}`} onClick={onRegisterFaceId} disabled={busy}><Fingerprint size={19} /><span><strong>{draftPasskey ? "Face ID／裝置密碼已加入" : "加入 Face ID／裝置密碼"}</strong><small>{draftPasskey ? "下次開啟日記時可直接驗證" : "使用 iPhone 的系統驗證"}</small></span>{draftPasskey && <Check size={17} />}</button><div className="unlock-divider"><span>設定自訂密碼（可選）</span></div><label className="composer-label">鎖定密碼<input value={passcode} onChange={(event) => setPasscode(event.target.value)} type="password" inputMode="numeric" autoComplete="new-password" placeholder="至少 4 碼" /></label><label className="composer-label">再次輸入<input value={confirmPasscode} onChange={(event) => setConfirmPasscode(event.target.value)} type="password" inputMode="numeric" autoComplete="new-password" placeholder="確認鎖定密碼" /></label>{error && <p className="security-error" role="alert">{error}</p>}{notice && <p className="security-notice">{notice}</p>}<div className="composer-actions"><button onClick={onClose}>取消</button><button className="save-button" onClick={onSave} disabled={busy}><Check size={15} />啟用日記鎖定</button></div></div></div>;
}

function SettingRow({ icon, tone, title, description, value, children, onClick }: { icon: React.ReactNode; tone: string; title: string; description: string; value?: string; children?: React.ReactNode; onClick?: () => void }) {
  return <button className="setting-row" onClick={onClick}><span className={`setting-icon ${tone}`}>{icon}</span><span className="setting-copy"><strong>{title}</strong><small>{description}</small></span>{value && <span className="setting-value">{value}</span>}{children}</button>;
}

function SettingsPage({ theme, setTheme, weekStart, setWeekStart, diaryLock, lockSettings, onToggleLock, onRefreshHolidays, holidayStatus, holidayStatusDetail, holidayCount, onImportData, onExportData }: { theme: "system" | "light" | "dark"; setTheme: (value: "system" | "light" | "dark") => void; weekStart: "sun" | "mon"; setWeekStart: (value: "sun" | "mon") => void; diaryLock: boolean; lockSettings: LockSettings; onToggleLock: () => void; onRefreshHolidays: () => void; holidayStatus: string; holidayStatusDetail: string; holidayCount: number; onImportData: () => void; onExportData: () => void }) {
  return <div className="settings-page"><div className="settings-appbar"><div className="settings-identity"><img src="/manus-storage/calendar-diary-logo_9eaa7769.png" alt="Calendar Diary" /><strong>Calendar Diary</strong><span>?</span></div><button className="qr-button" aria-label="顯示測試 QR Code" onClick={() => window.alert("QR Code 測試功能會在手機安裝流程中啟用。分頁目前可直接用網站預覽測試。")}><QrCode size={22} /></button></div><div className="settings-content"><div className="eyebrow">PREFERENCES</div><h1>設定</h1><section className="settings-section"><h2>一般</h2><div className="settings-card"><SettingRow icon={<Palette size={22} />} tone="blue" title="外觀" description="跟隨裝置的淺色／深色模式" value={theme === "system" ? "系統" : theme === "light" ? "淺色" : "深色"} onClick={() => setTheme(theme === "system" ? "light" : theme === "light" ? "dark" : "system")} /><SettingRow icon={<CalendarRange size={22} />} tone="amber" title="每週起始日" description={`月曆目前從${weekStart === "sun" ? "星期日" : "星期一"}開始`} value={weekStart === "sun" ? "週日" : "週一"} onClick={() => setWeekStart(weekStart === "sun" ? "mon" : "sun")} /><SettingRow icon={<LockKeyhole size={22} />} tone="purple" title="日記鎖定" description={diaryLock ? `${lockSettings.passkey ? "Face ID／裝置密碼" : "自訂鎖定密碼"} 已啟用` : "使用 Face ID、裝置密碼或自訂密碼保護日記"} value={diaryLock ? "已開啟" : "未開啟"} children={<span className={`toggle ${diaryLock ? "on" : ""}`}><span /></span>} onClick={onToggleLock} /></div></section><section className="settings-section"><h2>假日資料</h2><div className="settings-card holiday-settings-card"><SettingRow icon={<SunMedium size={22} />} tone="amber-soft" title="台灣國定假日" description={`政府資料鏡像 · 已載入 ${holidayCount} 個有名稱日期`} value={holidayStatus === "需要更新" ? "需要更新" : holidayStatus === "正在取得政府辦公日曆資料…" ? "更新中" : "完成更新"} /><button className="refresh-holidays" onClick={onRefreshHolidays}><RefreshCw size={18} />更新假日資料</button><span className="holiday-status">{holidayStatusDetail}</span></div></section><section className="settings-section"><h2>資料搬移</h2><div className="settings-card data-tools-card"><p>匯入你之前備份的 JSON，或先匯出目前日記留作備份。</p><div className="data-actions"><button className="data-action" onClick={onImportData}><Download size={17} />匯入日記 JSON</button><button className="data-action primary" onClick={onExportData}><Upload size={17} />匯出備份</button></div></div></section><section className="settings-section settings-about"><h2>關於</h2><div className="about-line"><span>版本</span><strong>1.0.0 · 正式版</strong></div></section></div></div>;
}

function ComposerModal({ composer, draftTitle, setDraftTitle, draftBody, setDraftBody, draftTime, setDraftTime, onSave, onClose }: { composer: Composer; draftTitle: string; setDraftTitle: (value: string) => void; draftBody: string; setDraftBody: (value: string) => void; draftTime: string; setDraftTime: (value: string) => void; onSave: () => void; onClose: () => void }) {
  const diary = composer.kind === "diary";
  return <div className="composer-backdrop" onClick={onClose}><div className="composer" onClick={(event) => event.stopPropagation()}><div className="composer-top"><div className="composer-kicker">{diary ? "DIARY NOTE" : "CALENDAR EVENT"}</div><button className="close-composer" onClick={onClose} aria-label="關閉"><X size={18} /></button></div><h2>{diary ? (composer.diaryId ? "重新編輯這一天" : "記下這一天") : "留下一個安排"}</h2>{diary ? <><label className="composer-label">標題<input value={draftTitle} onChange={(event) => setDraftTitle(event.target.value)} placeholder="替這段記錄取個名字" /></label><label className="composer-label">內文<textarea autoFocus value={draftBody} onChange={(event) => setDraftBody(event.target.value)} placeholder="今天有什麼值得記住？" /></label><div className="mood-picker"><span>今天的心情</span><div>{["平靜", "放鬆", "踏實", "開心"].map((mood) => <button key={mood} className={draftTime === mood ? "selected" : ""} onClick={() => setDraftTime(mood)}>{mood}</button>)}</div></div></> : <><label className="composer-label">事件名稱<input autoFocus value={draftTitle} onChange={(event) => setDraftTitle(event.target.value)} placeholder="例如：下午散步、回覆信件…" /></label><label className="composer-label">時間<input value={draftTime} onChange={(event) => setDraftTime(event.target.value)} placeholder="待安排" /></label></>}<div className="composer-actions"><button onClick={onClose}>取消</button><button className="save-button" onClick={onSave}><Check size={15} />保存{diary ? "日記" : "事件"}</button></div></div></div>;
}

export default function Home() {
  const [today, setToday] = useState(() => new Date());
  const [activeView, setActiveView] = useState(() => {
    const requestedView = new URLSearchParams(window.location.search).get("view");
    if (window.location.pathname === "/diary" || requestedView === "日記") return "日記";
    if (window.location.pathname === "/settings" || requestedView === "設定") return "設定";
    return "月曆";
  });
  const [visibleMonth, setVisibleMonth] = useState(() => new Date(today.getFullYear(), today.getMonth(), 1));
  const [selected, setSelected] = useState(dateKey(today));
  const autoMonthRef = useRef(`${today.getFullYear()}-${today.getMonth()}`);
  const [events, setEvents] = useState<EventItem[]>(() => loadCleanCollection(STORAGE_KEYS.events, eventSeed, STORAGE_KEYS.seedCleanupEvents, isDemoEvent));
  const [diaries, setDiaries] = useState<DiaryEntry[]>(() => loadCleanCollection(STORAGE_KEYS.diaries, diarySeed, STORAGE_KEYS.seedCleanupDiaries, isDemoDiary));
  const [holidayList, setHolidayList] = useState<Holiday[]>(() => {
    const stored = readLocal<Holiday[]>(STORAGE_KEYS.holidays, []);
    return addGovernmentMakeupHolidays([...stored, ...holidaySeed], 2026);
  });
  const importInputRef = useRef<HTMLInputElement>(null);
  const [composer, setComposer] = useState<Composer | null>(null);
  const [draftTitle, setDraftTitle] = useState("");
  const [draftBody, setDraftBody] = useState("");
  const [draftTime, setDraftTime] = useState("");
  const [theme, setTheme] = useState<"system" | "light" | "dark">(() => readLocal<{ theme?: "system" | "light" | "dark" }>(STORAGE_KEYS.settings, {}).theme ?? "system");
  const [systemDark, setSystemDark] = useState(() => typeof window !== "undefined" && window.matchMedia?.("(prefers-color-scheme: dark)").matches);
  const [weekStart, setWeekStart] = useState<"sun" | "mon">("sun");
  const [diaryLock, setDiaryLock] = useState(false);
  const [deviceCalendar, setDeviceCalendar] = useState(false);
  const [holidayStatus, setHolidayStatus] = useState("完成更新");
  const [holidayStatusDetail, setHolidayStatusDetail] = useState("目前使用已載入的假日資料");
  const networkWasOffline = useRef(false);
  const holidayRefreshInFlight = useRef(false);
  const [lockSettings, setLockSettings] = useState<LockSettings>(() => readLocal(STORAGE_KEYS.lock, { enabled: false }));
  const [isLocked, setIsLocked] = useState(() => readLocal<LockSettings>(STORAGE_KEYS.lock, { enabled: false }).enabled);
  const [securityMode, setSecurityMode] = useState<SecurityMode>(null);
  const [securityPasscode, setSecurityPasscode] = useState("");
  const [securityConfirmPasscode, setSecurityConfirmPasscode] = useState("");
  const [securityDraftPasskey, setSecurityDraftPasskey] = useState<LocalPasskey | undefined>();
  const [securityError, setSecurityError] = useState("");
  const [securityNotice, setSecurityNotice] = useState("");
  const [securityBusy, setSecurityBusy] = useState(false);

  useEffect(() => { window.localStorage.setItem(STORAGE_KEYS.diaries, JSON.stringify(diaries)); }, [diaries]);
  useEffect(() => { window.localStorage.setItem(STORAGE_KEYS.events, JSON.stringify(events)); }, [events]);
  useEffect(() => { window.localStorage.setItem(STORAGE_KEYS.holidays, JSON.stringify(holidayList)); }, [holidayList]);
  useEffect(() => { window.localStorage.setItem(STORAGE_KEYS.lock, JSON.stringify(lockSettings)); }, [lockSettings]);
  useEffect(() => { window.localStorage.setItem(STORAGE_KEYS.settings, JSON.stringify({ theme, weekStart, deviceCalendar, holidayStatus, holidayStatusDetail })); }, [theme, weekStart, deviceCalendar, holidayStatus, holidayStatusDetail]);
  useEffect(() => { const media = window.matchMedia?.("(prefers-color-scheme: dark)"); if (!media) return; const onChange = () => setSystemDark(media.matches); media.addEventListener?.("change", onChange); return () => media.removeEventListener?.("change", onChange); }, []);
  useEffect(() => {
    const now = new Date();
    const nextDay = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1, 0, 0, 1);
    const timer = window.setTimeout(() => setToday(new Date()), Math.max(1000, nextDay.getTime() - now.getTime()));
    return () => window.clearTimeout(timer);
  }, [today]);
  useEffect(() => {
    const monthKey = `${today.getFullYear()}-${today.getMonth()}`;
    if (autoMonthRef.current === monthKey) return;
    autoMonthRef.current = monthKey;
    setVisibleMonth(new Date(today.getFullYear(), today.getMonth(), 1));
    setSelected(dateKey(today));
  }, [today]);
  useEffect(() => { const onOffline = () => { networkWasOffline.current = true; }; const onOnline = () => { if (!networkWasOffline.current || holidayRefreshInFlight.current) return; networkWasOffline.current = false; setHolidayStatus("需要更新"); setHolidayStatusDetail("偵測到網路恢復，請按下更新假日資料"); }; window.addEventListener("offline", onOffline); window.addEventListener("online", onOnline); return () => { window.removeEventListener("offline", onOffline); window.removeEventListener("online", onOnline); }; }, []);
  const resolvedTheme = theme === "system" ? (systemDark ? "dark" : "light") : theme;

  function openDiary(diary?: DiaryEntry) {
    setDraftTitle(diary?.title ?? ""); setDraftBody(diary?.body ?? ""); setDraftTime(diary?.mood ?? "平靜"); setComposer({ kind: "diary", diaryId: diary?.id });
  }
    function openEvent(event?: EventItem) { setDraftTitle(event?.title ?? ""); setDraftBody(""); setDraftTime(event?.time ?? ""); setComposer({ kind: "event", eventId: event?.id }); }
  async function saveComposer() {
    if (!composer) return;
    const title = draftTitle.trim();
    const body = draftBody.trim();
    if (composer.kind === "diary") {
      if (!title && !body) { window.alert("請至少輸入日記內文或標題。"); return; }
      const safeTitle = title || body.slice(0, 24) || "未命名日記";
      if (composer.diaryId) setDiaries((current) => current.map((diary) => diary.id === composer.diaryId ? { ...diary, title: safeTitle, body, mood: draftTime || "平靜" } : diary));
      else setDiaries((current) => [{ id: `diary-${Date.now()}`, date: selected, title: safeTitle, body, mood: draftTime || "平靜" }, ...current]);
    } else {
      if (!title) { window.alert("請輸入日程名稱。"); return; }
      const oldEvent = composer.eventId ? events.find((item) => item.id === composer.eventId) : undefined;
      const nextEvent: EventItem = { id: oldEvent?.id ?? `event-${Date.now()}`, date: oldEvent?.date ?? selected, title, time: draftTime || "待安排", tone: oldEvent?.tone ?? "blue", nativeId: oldEvent?.nativeId, source: oldEvent?.source ?? "local" };
      setEvents((current) => composer.eventId ? current.map((event) => event.id === composer.eventId ? nextEvent : event) : [...current, nextEvent]);
      if (isNativeIOS()) {
        try {
          await requestNativeCalendarAccess();
          const isAllDay = !draftTime || draftTime === "待安排";
          const startDate = new Date(`${nextEvent.date}T${isAllDay ? "00:00" : draftTime}:00`);
          const endDate = isAllDay ? new Date(`${nextDate(nextEvent.date)}T00:00:00`) : new Date(startDate.getTime() + 60 * 60 * 1000);
          const payload = { title, startDate: startDate.getTime(), endDate: endDate.getTime(), isAllDay, notes: `Calendar Diary:${nextEvent.id}` };
          if (oldEvent?.nativeId) await modifyNativeEvent({ title: oldEvent.title, startDate: new Date(`${oldEvent.date}T${oldEvent.time && oldEvent.time !== "待安排" ? oldEvent.time : "00:00"}:00`).getTime(), endDate: new Date(`${oldEvent.date}T${oldEvent.time && oldEvent.time !== "待安排" ? oldEvent.time : "00:00"}:00`).getTime() + (oldEvent.time && oldEvent.time !== "待安排" ? 60 * 60 * 1000 : 24 * 60 * 60 * 1000) }, payload);
          else { const created = await createNativeEvent(payload); if (created.id) setEvents((current) => current.map((event) => event.id === nextEvent.id ? { ...event, nativeId: created.id, source: "local" } : event)); }
          setDeviceCalendar(true);
          if (draftTime && draftTime !== "待安排" && startDate.getTime() > Date.now()) { const notificationPermission = await LocalNotifications.requestPermissions(); if (notificationPermission.display === "granted") await LocalNotifications.schedule({ notifications: [{ id: Math.abs(nextEvent.id.split("").reduce((hash, char) => ((hash << 5) - hash + char.charCodeAt(0)) | 0, 0)), title, body: "Calendar Diary 日程提醒", schedule: { at: startDate }, extra: { eventId: nextEvent.id } }] }); }
        } catch (error) { window.alert(error instanceof Error ? `${error.message} 本機日程已保存，但尚未同步到 iPhone。` : "本機日程已保存，但尚未同步到 iPhone。"); }
      }
    }
    setComposer(null); setDraftTitle(""); setDraftBody(""); setDraftTime("");
  }
  function deleteDiary(diary: DiaryEntry) {
    setDiaries((current) => current.filter((item) => item.id !== diary.id));
  }
  async function deleteEvent(event: EventItem) {
    if (!window.confirm(`確定要刪除「${event.title}」嗎？這個動作無法復原。`)) return;
    setEvents((current) => current.filter((item) => item.id !== event.id));
    if (isNativeIOS() && event.nativeId) { try { await requestNativeCalendarAccess(); await deleteNativeEvent(event.nativeId); } catch { window.alert("App 內已刪除，但 iPhone 行事曆中的項目可能需要手動確認。"); } }
  }

  function openSecuritySetup() {
    setSecurityError(""); setSecurityNotice(""); setSecurityPasscode(""); setSecurityConfirmPasscode(""); setSecurityDraftPasskey(lockSettings.passkey); setSecurityMode("setup");
  }

  function toggleDiaryLock() {
    if (lockSettings.enabled) {
      if (window.confirm("要停用日記鎖定嗎？日記內容仍會保留在本機瀏覽器。")) { setLockSettings({ ...lockSettings, enabled: false }); setIsLocked(false); }
    } else openSecuritySetup();
  }

  async function registerFaceId() {
    setSecurityError(""); setSecurityNotice(""); setSecurityBusy(true);
    try {
      if (isNativeIOS()) { await BiometricAuth.checkBiometry(); setSecurityDraftPasskey({ credentialId: "native-ios-biometric", rpId: "native-ios" }); setSecurityNotice("已準備原生 Face ID／裝置密碼，請按下方按鈕保存設定。"); }
      else { const passkey = await registerLocalPasskey(); setSecurityDraftPasskey(passkey); setSecurityNotice("已完成 Face ID／裝置密碼註冊，請按下方按鈕保存設定。"); }
    } catch (error) { setSecurityError(error instanceof Error ? error.message : "無法完成裝置驗證，請確認你使用 HTTPS 的 Safari。 "); }
    finally { setSecurityBusy(false); }
  }

  async function saveSecuritySetup() {
    setSecurityError("");
    if (!securityDraftPasskey && !securityPasscode.trim()) { setSecurityError("請至少加入 Face ID／裝置密碼，或設定一組自訂密碼。"); return; }
    if (securityPasscode && securityPasscode.length < 4) { setSecurityError("自訂鎖定密碼至少需要 4 碼。"); return; }
    if (securityPasscode !== securityConfirmPasscode) { setSecurityError("兩次輸入的鎖定密碼不一致。"); return; }
    setSecurityBusy(true);
    try {
      const nextSettings: LockSettings = { enabled: true, passkey: securityDraftPasskey, nativeBiometric: isNativeIOS() && Boolean(securityDraftPasskey?.credentialId === "native-ios-biometric") };
      if (securityPasscode) { const salt = createSalt(); nextSettings.passcodeSalt = salt; nextSettings.passcodeHash = await hashPasscode(securityPasscode, salt); }
      setLockSettings(nextSettings); setIsLocked(true); setSecurityMode(null); setSecurityPasscode(""); setSecurityConfirmPasscode("");
    } catch (error) { setSecurityError(error instanceof Error ? error.message : "無法保存鎖定設定。"); }
    finally { setSecurityBusy(false); }
  }

  async function unlockWithPasscode() {
    if (!lockSettings.passcodeHash || !lockSettings.passcodeSalt) return;
    setSecurityError(""); setSecurityBusy(true);
    try { const hash = await hashPasscode(securityPasscode, lockSettings.passcodeSalt); if (hash !== lockSettings.passcodeHash) { setSecurityError("鎖定密碼不正確。"); return; } setIsLocked(false); setSecurityMode(null); setSecurityPasscode(""); }
    catch (error) { setSecurityError(error instanceof Error ? error.message : "無法驗證鎖定密碼。"); }
    finally { setSecurityBusy(false); }
  }

  async function unlockWithFaceId() {
    if (!lockSettings.passkey) return;
    setSecurityError(""); setSecurityBusy(true);
    try {
      if (lockSettings.nativeBiometric && isNativeIOS()) await BiometricAuth.authenticate({ reason: "解鎖你的日記", allowDeviceCredential: true, iosFallbackTitle: "使用 iPhone 密碼" });
      else { const success = await authenticateLocalPasskey(lockSettings.passkey); if (!success) throw new Error("裝置驗證未完成。"); }
      setIsLocked(false); setSecurityMode(null);
    } catch (error) { setSecurityError(error instanceof Error ? error.message : "Face ID／裝置密碼驗證失敗。"); }
    finally { setSecurityBusy(false); }
  }

  async function syncWithDeviceCalendar() {
    if (!isNativeIOS()) { window.alert("目前是 PWA 預覽。請用 Codemagic 側載的原生 iOS App，才能請求行事曆讀寫權限。"); return; }
    try {
      const permissions = await requestNativeCalendarAccess();
      if (permissions.readCalendar !== "granted") throw new Error("你尚未允許讀取 iPhone 行事曆。");
      const start = new Date(); start.setFullYear(start.getFullYear() - 1); start.setHours(0, 0, 0, 0);
      const end = new Date(); end.setFullYear(end.getFullYear() + 2); end.setHours(23, 59, 59, 999);
      const deviceEvents = await listNativeEvents(start.getTime(), end.getTime());
      const imported: EventItem[] = deviceEvents.map((item) => { const date = new Date(item.startDate); return { id: `device-${item.id}`, nativeId: item.id, source: "device", date: dateKey(date), title: item.title || "未命名日程", time: item.isAllDay ? "全天" : `${String(date.getHours()).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}`, tone: "blue" }; });
      setEvents((current) => [...current.filter((item) => item.source !== "device"), ...imported]);
      setDeviceCalendar(true);
      window.alert(`已同步 ${imported.length} 筆 iPhone 行事曆事件。`);
    } catch (error) { window.alert(error instanceof Error ? error.message : "無法同步 iPhone 行事曆。"); }
  }

  async function writeHolidaysToDevice(year: number, updated: Holiday[]) {
    if (!isNativeIOS()) return;
    const permissions = await requestNativeCalendarAccess();
    if (permissions.writeCalendar !== "granted") throw new Error("你尚未允許寫入 iPhone 行事曆。");
    const existing = await listManagedHolidayEvents();
    const byKey = new Map(existing.map((event) => [event.notes || event.title || event.id, event]));
    for (const holiday of updated.filter((item) => item.date.startsWith(`${year}-`))) {
      const startDate = new Date(`${holiday.date}T00:00:00`);
      const endDate = new Date(`${nextDate(holiday.date)}T00:00:00`);
      const noteKey = `Calendar Diary Holiday:${holiday.date}`;
      const payload = { title: `台灣假日｜${holiday.name}`, startDate: startDate.getTime(), endDate: endDate.getTime(), isAllDay: true, notes: noteKey };
      const old = byKey.get(noteKey);
      if (old) await modifyNativeEvent({ title: old.title, startDate: old.startDate, endDate: old.endDate }, payload);
      else await createNativeEvent(payload);
      byKey.delete(noteKey);
    }
    for (const stale of Array.from(byKey.values())) { if ((stale.notes || "").startsWith("Calendar Diary Holiday:")) await deleteNativeEvent(stale.id); }
  }

  async function refreshHolidays() {
    const previousStatus = holidayStatus === "需要更新" ? "需要更新" : "完成更新";
    holidayRefreshInFlight.current = true;
    setHolidayStatus("正在取得政府辦公日曆資料…");
    try {
      const year = new Date().getFullYear();
      const response = await fetch(`${HOLIDAY_SOURCE}${year}.json`, { cache: "no-store" });
      if (!response.ok) throw new Error("資料來源暫時無法連線");
      const records = await response.json() as Array<{ date?: string; isHoliday?: boolean; description?: string }>;
      const parsed = records.map(normalizeHolidayRecord).filter((item): item is Holiday => Boolean(item));
      const updated = addGovernmentMakeupHolidays(parsed, year);
      if (!updated.length) throw new Error("沒有讀到有效的假日資料");
      const existing = holidayList.filter((holiday) => holiday.date.startsWith(`${year}-`));
      const changed = existing.length !== updated.length || updated.some((holiday) => {
        const previous = existing.find((item) => item.date === holiday.date);
        return !previous || previous.name !== holiday.name || previous.dayOff !== holiday.dayOff;
      });
      if (changed) setHolidayList((current) => [...current.filter((holiday) => !holiday.date.startsWith(`${year}-`)), ...updated]);
      if (isNativeIOS()) await writeHolidaysToDevice(year, updated);
      setHolidayStatus("完成更新");
      setHolidayStatusDetail(changed ? `已更新 ${year} 年資料 · ${updated.length} 個節日` : `${year} 年資料沒有變更 · 維持完成更新`);
    } catch (error) {
      setHolidayStatus(previousStatus);
      setHolidayStatusDetail(error instanceof Error ? `${error.message} · 保留目前資料` : "更新失敗 · 保留目前資料");
    } finally {
      holidayRefreshInFlight.current = false;
    }
  }

  function exportCalendar() {
    const now = new Date();
    const lines = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Calendar Diary//TW", "CALSCALE:GREGORIAN", "X-WR-CALNAME:Calendar Diary"];
    events.forEach((item) => {
      const start = icsDateTime(item.date, item.time);
      const end = icsEndDateTime(item.date, item.time);
      lines.push("BEGIN:VEVENT", `UID:${escapeIcs(item.id)}@calendar-diary`, `DTSTAMP:${now.toISOString().replace(/[-:.TZ]/g, "").slice(0, 15)}Z`, start && end ? `DTSTART:${start}` : `DTSTART;VALUE=DATE:${icsDate(item.date)}`, end ? `DTEND:${end}` : `DTEND;VALUE=DATE:${icsDate(nextDate(item.date))}`, `SUMMARY:${escapeIcs(item.title)}`, `DESCRIPTION:${escapeIcs(item.time || "全天")}`, "END:VEVENT");
    });
    lines.push("END:VCALENDAR");
    const blob = new Blob([lines.join("\\r\\n")], { type: "text/calendar;charset=utf-8" });
    const url = URL.createObjectURL(blob); const anchor = document.createElement("a"); anchor.href = url; anchor.download = `calendar-diary-${dateKey(now)}.ics`; anchor.click(); window.setTimeout(() => URL.revokeObjectURL(url), 1000);
    window.alert(events.length ? "已產生 iPhone 行事曆檔案，請在 iPhone 開啟後加入行事曆。" : "目前沒有日程可匯出，請先新增日程。");
  }

  function exportData() {
    const payload = { format: "calendar-diary", version: 1, exportedAt: new Date().toISOString(), diaries, events, holidays: holidayList };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a"); anchor.href = url; anchor.download = `calendar-diary-backup-${dateKey(new Date())}.json`; anchor.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  async function importData(event: React.ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    try {
      const rawPayload = JSON.parse(await file.text()) as unknown;
      const payload = (Array.isArray(rawPayload) ? { diaries: rawPayload } : rawPayload) as { diaries?: unknown; events?: unknown; holidays?: unknown };
      const importedDiaries = Array.isArray(payload.diaries) ? payload.diaries.flatMap((item, index) => { if (!item || typeof item !== "object") return []; const value = item as Partial<DiaryEntry> & { content?: string }; if (typeof value.date !== "string" || typeof value.title !== "string") return []; return [{ id: typeof value.id === "string" ? value.id : `diary-import-${Date.now()}-${index}`, date: value.date, title: value.title, body: typeof value.body === "string" ? value.body : (value.content ?? ""), mood: typeof value.mood === "string" ? value.mood : "平靜" }]; }) : [];
      const importedEvents = Array.isArray(payload.events) ? payload.events.flatMap((item, index) => { if (!item || typeof item !== "object") return []; const value = item as Partial<EventItem>; if (typeof value.date !== "string" || typeof value.title !== "string") return []; return [{ id: typeof value.id === "string" ? value.id : `event-import-${Date.now()}-${index}`, date: value.date, title: value.title, time: typeof value.time === "string" ? value.time : "待安排", tone: value.tone === "amber" || value.tone === "green" ? value.tone : "blue" as const }]; }) : [];
      const importedHolidays = Array.isArray(payload.holidays) ? payload.holidays.flatMap((item) => { if (!item || typeof item !== "object") return []; const value = item as Partial<Holiday> & { description?: string; isHoliday?: boolean }; if (typeof value.date !== "string") return []; const name = typeof value.name === "string" ? value.name : value.description; if (!name) return []; return [{ date: value.date, name, dayOff: typeof value.dayOff === "boolean" ? value.dayOff : Boolean(value.isHoliday) }]; }) : [];
      if (!importedDiaries.length && !importedEvents.length && !importedHolidays.length) throw new Error("檔案內沒有可匯入的 Calendar Diary 資料。");
      setDiaries((current) => mergeById(current, importedDiaries));
      setEvents((current) => mergeById(current, importedEvents));
      if (importedHolidays.length) setHolidayList((current) => { const map = new Map(current.map((item) => [item.date, item])); importedHolidays.forEach((item) => map.set(item.date, item)); return Array.from(map.values()); });
      window.alert(`匯入完成：${importedDiaries.length} 篇日記、${importedEvents.length} 個事件、${importedHolidays.length} 個假日。`);
    } catch (error) { window.alert(error instanceof Error ? error.message : "無法讀取這個 JSON 備份檔。"); }
  }

  return <div className="app-shell" data-theme={resolvedTheme}><AppSidebar active={activeView} onChange={setActiveView} onNewDiary={() => openDiary()} /><main className="main-area"><header className="topbar"><button className="mobile-menu" aria-label={activeView === "設定" ? "返回月曆" : "開啟選單"} onClick={() => activeView === "設定" ? setActiveView("月曆") : setActiveView("日記")}>{activeView === "設定" ? <ArrowLeft size={20} /> : <Menu size={20} />}</button><div className="breadcrumbs"><span>我的日常</span><span className="crumb-separator">/</span><strong>{activeView}</strong></div><div className="top-actions"><button className="icon-button" aria-label="搜尋日記" onClick={() => setActiveView("日記")}><Search size={18} /></button>{activeView === "月曆" && <button className="today-button" onClick={() => { setVisibleMonth(new Date(today.getFullYear(), today.getMonth(), 1)); setSelected(dateKey(today)); }}>今天</button>}<img className="mini-avatar topbar-mark" src="/manus-storage/calendar-diary-logo_9eaa7769.png" alt="Calendar Diary" /></div></header>{activeView === "月曆" ? <CalendarPage visibleMonth={visibleMonth} setVisibleMonth={setVisibleMonth} selected={selected} setSelected={setSelected} events={events} diaries={diaries} today={today} weekStart={weekStart} holidayList={holidayList} onNewDiary={() => openDiary()} onNewEvent={openEvent} onEditEvent={openEvent} onDeleteEvent={deleteEvent} /> : activeView === "日記" ? (isLocked ? <div className="page-shell locked-page"><LockScreen lockSettings={lockSettings} passcode={securityPasscode} setPasscode={setSecurityPasscode} error={securityError} busy={securityBusy} onUnlockPasscode={unlockWithPasscode} onUnlockFaceId={unlockWithFaceId} /></div> : <DiaryPage diaries={diaries} onNewDiary={() => openDiary()} onEditDiary={openDiary} onDeleteDiary={deleteDiary} />) : <SettingsPage theme={theme} setTheme={setTheme} weekStart={weekStart} setWeekStart={setWeekStart} diaryLock={lockSettings.enabled} lockSettings={lockSettings} onToggleLock={toggleDiaryLock} onRefreshHolidays={refreshHolidays} holidayStatus={holidayStatus} holidayStatusDetail={holidayStatusDetail} holidayCount={holidayList.length} onImportData={() => importInputRef.current?.click()} onExportData={exportData} />}<BottomNav active={activeView} onChange={setActiveView} /></main><input ref={importInputRef} className="visually-hidden" type="file" accept="application/json,.json" onChange={importData} />{composer && <ComposerModal composer={composer} draftTitle={draftTitle} setDraftTitle={setDraftTitle} draftBody={draftBody} setDraftBody={setDraftBody} draftTime={draftTime} setDraftTime={setDraftTime} onSave={saveComposer} onClose={() => setComposer(null)} />}{securityMode === "unlock" && activeView !== "日記" && <div className="security-overlay"><LockScreen lockSettings={lockSettings} passcode={securityPasscode} setPasscode={setSecurityPasscode} error={securityError} busy={securityBusy} onUnlockPasscode={unlockWithPasscode} onUnlockFaceId={unlockWithFaceId} /></div>}{securityMode === "setup" && <SecuritySetupModal passcode={securityPasscode} setPasscode={setSecurityPasscode} confirmPasscode={securityConfirmPasscode} setConfirmPasscode={setSecurityConfirmPasscode} draftPasskey={securityDraftPasskey} error={securityError} notice={securityNotice} busy={securityBusy} onRegisterFaceId={registerFaceId} onSave={saveSecuritySetup} onClose={() => setSecurityMode(null)} />}</div>;
}
