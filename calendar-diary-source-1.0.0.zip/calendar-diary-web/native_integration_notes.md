# 原生 iOS 整合依據

## 官方文件

- Capacitor 自訂 iOS 程式碼：https://capacitorjs.com/docs/ios/custom-code
- Capacitor iOS Plugin Guide：https://capacitorjs.com/docs/plugins/ios
- Codemagic 原生 iOS 建置：https://docs.codemagic.io/yaml-quick-start/building-a-native-ios-app/
- Codemagic Capacitor 建置：https://docs.codemagic.io/yaml-quick-start/building-an-ionic-app/
- Codemagic iOS 簽署：https://docs.codemagic.io/yaml-code-signing/signing-ios/

## 已確認事項

1. Capacitor 可在現有 Web 專案外包裝原生 iOS 外殼；原生功能需透過 Capacitor Plugin 從 JavaScript 呼叫。
2. Capacitor 官方自訂 Plugin 需要 Swift 類別實作 `CAPPlugin` 與 `CAPBridgedPlugin`，並在原生 ViewController 的 `capacitorDidLoad()` 註冊；Web 端使用 `registerPlugin()`。
3. 已加入 `@capacitor/calendar`，其 API 提供 `requestPermissions`、`findEvents`、`createEvent`、`modifyEvent`、`deleteEvent`、`listCalendars` 與 `openCalendar`，可作為 iOS EventKit 橋接。
4. 已加入 `@capacitor/local-notifications` 與 `@capacitor/preferences`，可供本地通知與原生偏好資料保存。
5. Codemagic 文件確認 `codemagic.yaml` 必須放在 GitHub repository 根目錄；iOS 實機 IPA 建置必須進行程式簽署，Codemagic 文件描述的憑證／Provisioning Profile 流程以 Apple Developer Program 為前提。
6. 原生 iOS 需要在 Info.plist 提供行事曆與 Face ID 的隱私說明，至少包含 `NSCalendarsUsageDescription`、`NSCalendarsFullAccessUsageDescription` 與 `NSFaceIDUsageDescription`。
7. 目前專案仍保留 PWA；瀏覽器預覽不會實作原生 Calendar API，會以錯誤提示安全退化。
