# 原生整合預覽驗證

- TypeScript、Vite production build、Capacitor iOS sync 與 codemagic.yaml 格式檢查均通過。
- 設定頁已恢復「iPhone 系統行事曆」列；PWA 顯示「需原生 App」，側載原生版可使用 EventKit 雙向同步。
- 設定頁已恢復「匯出至 iPhone 行事曆」入口；PWA 會輸出 `.ics`，原生版則可讀寫裝置行事曆。
- 台灣假日更新在原生版會取得資料後建立／修改／刪除 Calendar Diary 管理的假日事件；不會刪除其他私人行程。
- PWA 預覽仍維持瀏覽器安全退化訊息，不會假裝可直接讀取 iPhone 系統行事曆。
- 實際 iOS EventKit、Face ID、通知與免費 Apple ID 側載尚未在本 Linux 工作區執行，必須由 Codemagic 建置後在 iPhone 測試。
